#!/bin/bash

make
./bin/main
make clean
